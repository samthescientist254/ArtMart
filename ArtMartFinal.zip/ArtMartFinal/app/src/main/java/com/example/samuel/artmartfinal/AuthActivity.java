package com.example.samuel.artmartfinal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class AuthActivity extends AppCompatActivity implements View.OnClickListener{
private EditText editTextEmail,editTextPassword;
private Button btnRegister;
private TextView txtSignIn;
private ProgressDialog progressDialog;
FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        firebaseAuth= FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser()!=null){
            finish();
            startActivity(new Intent(AuthActivity.this,MainActivity.class));
        }
        progressDialog=new ProgressDialog(AuthActivity.this);
        editTextEmail=findViewById(R.id.editTextEmail);
        editTextPassword=findViewById(R.id.editTextPassword);
        btnRegister=findViewById(R.id.btnRegister);
        txtSignIn=findViewById(R.id.txtSignIn);

        btnRegister.setOnClickListener(this);
        txtSignIn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==btnRegister){
            registerUser();
        }
        if(v==txtSignIn){
            finish();
           startActivity(new Intent (AuthActivity.this,LoginActivity.class));
        }

    }
   private void registerUser(){
    String email=editTextEmail.getText().toString().trim();
    String password = editTextPassword.getText().toString().trim();
    if(TextUtils.isEmpty(email)){
        Toast.makeText(AuthActivity.this,"Enter your email",Toast.LENGTH_SHORT).show();
        return;
    }
    if(TextUtils.isEmpty(password)){
        Toast.makeText(AuthActivity.this,"Enter your password",Toast.LENGTH_SHORT).show();
        return;
    }
    progressDialog.setMessage("Registering user");
    progressDialog.show();
    firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
        @Override
        public void onComplete(@NonNull Task<AuthResult> task) {
            if(task.isSuccessful()){
                Toast.makeText(AuthActivity.this,"Registration was successful...",Toast.LENGTH_SHORT).show();
                finish();
                startActivity(new Intent (AuthActivity.this,LoginActivity.class));
            }
            else {
                Toast.makeText(AuthActivity.this,"failed to register Try again",Toast.LENGTH_SHORT).show();
                return;
            }
            progressDialog.dismiss();
        }
    });
    }

}
