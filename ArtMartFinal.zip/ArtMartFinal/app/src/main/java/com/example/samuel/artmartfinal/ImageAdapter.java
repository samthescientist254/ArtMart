package com.example.samuel.artmartfinal;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.imageViewHolder> {
    private Context mContext;
    private List<upload> mUploads;
    private onItemClickListener mListener;
    public ImageAdapter (Context context,List<upload>uploads){
        mContext=context;
        mUploads=uploads;
    }
    public imageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(mContext).inflate(R.layout.image_item,parent,false);
        return new imageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull imageViewHolder holder, int position) {
      upload uploadCurrent=mUploads.get(position);
      holder.textViewName.setText(uploadCurrent.getName());
        Picasso.with(mContext)
                .load(uploadCurrent.getImageUrl())
                .placeholder(R.mipmap.ic_launcher)
                .fit()
                .centerCrop()
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public class imageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener,View.OnCreateContextMenuListener,MenuItem.OnMenuItemClickListener{
        public TextView textViewName;
        public ImageView imageView;
        public imageViewHolder(View itemView) {
            super(itemView);
            textViewName=itemView.findViewById(R.id.txt_name);
            imageView=itemView.findViewById(R.id.image_view_upload);
            itemView.setOnClickListener(this);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onClick(View v) {
            if(mListener!=null){
                int position= getAdapterPosition();
                if(position!=RecyclerView.NO_POSITION){
                    mListener.onItemClickListener(position);
                }
            }
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            menu.setHeaderTitle("Select Action");
            MenuItem doWhatever=menu.add(Menu.NONE,1,1,"Do Whatever");
            MenuItem delete=menu.add(Menu.NONE,2,2,"Delete");
            MenuItem buy=menu.add(Menu.NONE,3,3,"Buy");

            doWhatever.setOnMenuItemClickListener(this);
            delete.setOnMenuItemClickListener(this);
            buy.setOnMenuItemClickListener(this);
        }

        @Override
        public boolean onMenuItemClick(MenuItem item) {
            if(mListener!=null){
                int position= getAdapterPosition();
                if(position!=RecyclerView.NO_POSITION){
                   switch (item.getItemId()){
                       case 1:
                           mListener.onWhateverClickListener(position);
                           return true;
                       case 2:
                           mListener.onDeleteClickListener(position);
                           return true;
                       case 3:mListener.OnBuyClickListener(position);
                   }
                }
            }
            return false;
        }
    }
    public interface onItemClickListener{
        void onItemClickListener(int position);
        void onWhateverClickListener(int position);
        void onDeleteClickListener(int position);
        void OnBuyClickListener(int position);
    }
    public void setOnItemClickListener(onItemClickListener listener){
     mListener=listener;
    }
}
