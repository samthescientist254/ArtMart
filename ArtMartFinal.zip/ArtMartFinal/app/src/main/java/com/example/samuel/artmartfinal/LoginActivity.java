package com.example.samuel.artmartfinal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ButtonBarLayout;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
private EditText  editTextEmail, editTextPassword;
private Button buttonSignIn,buttonUserSignIn;
private TextView txtSignUp;
private ProgressDialog progressDialog;
private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth=FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        }
        progressDialog=new ProgressDialog(LoginActivity.this);
        editTextEmail=findViewById(R.id.editTextEmail2);
        editTextPassword=findViewById(R.id.editTextPassword1);
        buttonSignIn=findViewById(R.id.btnSignIn);
        buttonUserSignIn=findViewById(R.id.btnUserSignIn);
        txtSignUp =findViewById(R.id.txtSignUp);
        buttonSignIn.setOnClickListener(this);
        buttonUserSignIn.setOnClickListener(this);
        txtSignUp.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==buttonSignIn){
         userLogin();
        }
        if(v== txtSignUp){
            finish();
            startActivity(new Intent(LoginActivity.this,AuthActivity.class));
        }
        if(v==buttonUserSignIn){
           GeneralUserLogin();
        }
    }
    private void userLogin(){
        String email=editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        if(TextUtils.isEmpty(email)){
            Toast.makeText(LoginActivity.this,"Enter your email",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(LoginActivity.this,"Enter your password",Toast.LENGTH_SHORT).show();
            return;
        }
        progressDialog.setMessage("Registering please wait.........");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
              progressDialog.dismiss();
              if(task.isSuccessful()){
                  finish();
                  startActivity(new Intent(getApplicationContext(),MainActivity.class));
              }
            }
        });
    }
    private void GeneralUserLogin(){
        String email=editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        if(TextUtils.isEmpty(email)){
            Toast.makeText(LoginActivity.this,"Enter your email",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(LoginActivity.this,"Enter your password",Toast.LENGTH_SHORT).show();
            return;
        }
        progressDialog.setMessage("Registering please wait.........");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressDialog.dismiss();
                if(task.isSuccessful()){
                    finish();
                    startActivity(new Intent(getApplicationContext(),GeneralUser.class));
                }
            }
        });
    }
}
